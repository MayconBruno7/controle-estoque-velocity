<p>
    O VelocityPHP é um micro framework PHP que será criado com fins acadêmicos durante o 5º período na disciplina Frameworks I do curso de análise de 
    desenvolvimento de sistemas da Faculdade Santa Marcelinas unidade Muriaé. Ele permite o uso de rotas inteligentes, arquivos de configuração, AutoLoad, 
    MVC, classe de conexão com base de dados MySQL e SQL Server com métodos de abstração dos comandos SQL.
</p>