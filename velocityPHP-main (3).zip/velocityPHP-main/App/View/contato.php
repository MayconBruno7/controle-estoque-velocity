<section>
    <h3>Contato</h3>
    <p>
        E-mail: contato@velocityphp.com.br<br>
        Telefone: (32) 98765-4321
    </p>
</section>