<?php

    // Constantes utilizadas no AutoLoad
    define("DS", DIRECTORY_SEPARATOR);
    define("ROOT", __FILE__);